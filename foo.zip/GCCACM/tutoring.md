---
layout: page
title: ~/tutoring
permalink: /tutoring/
---
# ~/tutoring
ACM tutoring takes place every Thursday from 7 PM - 9 PM during the school year. Usually we meet at STEM 376 (Hoyt side of STEM), but during distance learning we use a Microsoft Teams team. Check back here for more details on that team as the need arises. <br>
We tutor freshman COMP courses: COMP 141, 155, and 220. Give us a visit for help in these classes or general academic advice. <br>
Dusty veterans of 141 and 220, help us tutor! Drop in any night, your assistance is much appreciated! :)

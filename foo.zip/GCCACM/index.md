---
title: ~/
layout: page
permalink: /
---
# ~/
![header](/assets/images/header.jpg)
Hi there! We are Grove City ACM. More specifically, we are a chapter of the multi-national computing society ACM, Association for Computing Machinery. Here at Grove City, we put on events for those who are interested in computers, and provide academic support to those who are studying them. Currently, membership is very relaxed and our events/tutoring sessions are open to all. Click around this site for more information.
